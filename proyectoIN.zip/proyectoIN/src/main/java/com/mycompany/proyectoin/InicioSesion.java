
package com.mycompany.proyectoin;

import java.awt.*;
import javax.swing.*;

public class InicioSesion extends JFrame {

    private final Color oscuro = new Color(6, 72, 63);
    private final Color verde = new Color(0, 134, 106);

    public InicioSesion() {
        setTitle("ENPH - Inicio de sesión");
        setSize(430, 390);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(0, 1, 10, 10));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(35, 45, 35, 45));

        JLabel titulo = new JLabel("ENPH", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 34));
        titulo.setForeground(oscuro);

        JLabel subtitulo = new JLabel(
                "Sistema de información del hogar",
                SwingConstants.CENTER);

        JTextField cedula = new JTextField();
        JPasswordField clave = new JPasswordField();

        JButton ingresar = new JButton("Ingresar");
        ingresar.setBackground(verde);
        ingresar.setForeground(Color.WHITE);

        panel.add(titulo);
        panel.add(subtitulo);
        panel.add(new JLabel("Cédula:"));
        panel.add(cedula);
        panel.add(new JLabel("Contraseña:"));
        panel.add(clave);
        panel.add(ingresar);

        add(panel);

        ingresar.addActionListener(e -> {
            String documento = cedula.getText().trim();
            String password = new String(clave.getPassword());

            if (documento.equals("1097101337")
                    && password.equals("1097101337")) {
                new MenuPrincipal().setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Cédula o contraseña incorrecta.");
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() ->
                new InicioSesion().setVisible(true));
    }
}
