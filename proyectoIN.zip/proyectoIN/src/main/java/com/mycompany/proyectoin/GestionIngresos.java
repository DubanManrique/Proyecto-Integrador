
package com.mycompany.proyectoin;

import java.awt.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class GestionIngresos extends JFrame {

    private JTextField fecha, descripcion, valor;
    private JComboBox<String> tipo;
    private JTable tabla;
    private DefaultTableModel modelo;
    private int siguienteId = 1;

    public GestionIngresos() {
        setTitle("ENPH - Gestión de ingresos");
        setSize(850, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        Color oscuro = new Color(6, 72, 63);
        Color verde = new Color(0, 134, 106);

        JPanel principal = new JPanel(new BorderLayout(10, 10));
        principal.setBackground(new Color(240, 245, 247));
        principal.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JLabel titulo = new JLabel("GESTIÓN DE INGRESOS DEL HOGAR");
        titulo.setFont(new Font("Arial", Font.BOLD, 23));
        titulo.setForeground(oscuro);
        principal.add(titulo, BorderLayout.NORTH);

        fecha = new JTextField(LocalDate.now().toString());
        descripcion = new JTextField();
        valor = new JTextField();

        tipo = new JComboBox<>(new String[]{
            "Salario", "Trabajo independiente", "Pensión",
            "Ayuda familiar", "Arriendo recibido", "Otros"
        });

        JPanel formulario = new JPanel(new GridLayout(3, 2, 10, 10));
        formulario.setBackground(Color.WHITE);
        formulario.setBorder(BorderFactory.createTitledBorder(
                "Información del ingreso"));

        formulario.add(new JLabel("Fecha (AAAA-MM-DD):"));
        formulario.add(fecha);
        formulario.add(new JLabel("Descripción o procedencia:"));
        formulario.add(descripcion);
        formulario.add(new JLabel("Tipo de ingreso:"));
        formulario.add(tipo);
        formulario.add(new JLabel("Valor (COP):"));
        formulario.add(valor);

        modelo = new DefaultTableModel(new String[]{
            "ID", "Fecha", "Descripción", "Tipo", "Valor (COP)"
        }, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };

        tabla = new JTable(modelo);
        tabla.setRowHeight(24);
        tabla.getTableHeader().setBackground(new Color(215, 235, 230));

        JPanel centro = new JPanel(new BorderLayout(10, 10));
        centro.setOpaque(false);
        centro.add(formulario, BorderLayout.NORTH);
        centro.add(new JScrollPane(tabla), BorderLayout.CENTER);

        JButton guardar = new JButton("Guardar");
        JButton modificar = new JButton("Modificar");
        JButton eliminar = new JButton("Eliminar");
        JButton limpiar = new JButton("Limpiar");
        JButton volver = new JButton("Volver al menú");

        guardar.setBackground(verde);
        guardar.setForeground(Color.WHITE);

        JPanel botones = new JPanel(new FlowLayout());
        botones.setOpaque(false);
        botones.add(guardar);
        botones.add(modificar);
        botones.add(eliminar);
        botones.add(limpiar);
        botones.add(volver);

        principal.add(centro, BorderLayout.CENTER);
        principal.add(botones, BorderLayout.SOUTH);
        add(principal);

        guardar.addActionListener(e -> guardarIngreso());
        modificar.addActionListener(e -> modificarIngreso());
        eliminar.addActionListener(e -> eliminarIngreso());
        limpiar.addActionListener(e -> limpiar());
        volver.addActionListener(e -> dispose());

        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow() >= 0) {
                cargarSeleccion();
            }
        });
    }

    private BigDecimal leerValor() {
        return new BigDecimal(valor.getText().trim().replace(",", "."));
    }

    private boolean validar() {
        try {
            LocalDate.parse(fecha.getText().trim());

            if (descripcion.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Escribe la descripción del ingreso.");
                return false;
            }

            if (leerValor().compareTo(BigDecimal.ZERO) <= 0) {
                JOptionPane.showMessageDialog(this,
                        "El valor debe ser mayor que cero.");
                return false;
            }

            return true;
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Revisa la fecha y el valor del ingreso.");
            return false;
        }
    }

    private void guardarIngreso() {
        if (!validar()) return;

        modelo.addRow(new Object[]{
            siguienteId++, fecha.getText().trim(),
            descripcion.getText().trim(), tipo.getSelectedItem(), leerValor()
        });

        limpiar();
        JOptionPane.showMessageDialog(this, "Ingreso guardado.");
    }

    private void modificarIngreso() {
        int f = tabla.getSelectedRow();

        if (f < 0) {
            JOptionPane.showMessageDialog(this, "Selecciona un ingreso.");
            return;
        }
        if (!validar()) return;

        modelo.setValueAt(fecha.getText().trim(), f, 1);
        modelo.setValueAt(descripcion.getText().trim(), f, 2);
        modelo.setValueAt(tipo.getSelectedItem(), f, 3);
        modelo.setValueAt(leerValor(), f, 4);

        limpiar();
        JOptionPane.showMessageDialog(this, "Ingreso modificado.");
    }

    private void eliminarIngreso() {
        int f = tabla.getSelectedRow();

        if (f < 0) {
            JOptionPane.showMessageDialog(this, "Selecciona un ingreso.");
            return;
        }

        if (JOptionPane.showConfirmDialog(this,
                "¿Eliminar este ingreso?", "Confirmar",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            modelo.removeRow(f);
            limpiar();
        }
    }

    private void cargarSeleccion() {
        int f = tabla.getSelectedRow();
        if (f < 0) return;

        fecha.setText(modelo.getValueAt(f, 1).toString());
        descripcion.setText(modelo.getValueAt(f, 2).toString());
        tipo.setSelectedItem(modelo.getValueAt(f, 3));
        valor.setText(modelo.getValueAt(f, 4).toString());
    }

    private void limpiar() {
        fecha.setText(LocalDate.now().toString());
        descripcion.setText("");
        valor.setText("");
        tipo.setSelectedIndex(0);
        tabla.clearSelection();
    }
}
