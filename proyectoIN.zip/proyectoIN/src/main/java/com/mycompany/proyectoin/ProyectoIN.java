
package com.mycompany.proyectoin;

import javax.swing.SwingUtilities;

public class ProyectoIN {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new InicioSesion().setVisible(true);
        });
    }
}
