
package com.mycompany.proyectoin;

import java.awt.*;
import javax.swing.*;

public class MenuPrincipal extends JFrame {

    private final Color oscuro = new Color(6, 72, 63);
    private final Color verde = new Color(0, 134, 106);

    public MenuPrincipal() {
        setTitle("ENPH - Menú principal");
        setSize(750, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel principal = new JPanel(new BorderLayout());
        principal.setBackground(new Color(240, 245, 247));

        JPanel lateral = new JPanel();
        lateral.setBackground(oscuro);
        lateral.setPreferredSize(new Dimension(175, 0));
        lateral.setLayout(new BoxLayout(lateral, BoxLayout.Y_AXIS));
        lateral.setBorder(BorderFactory.createEmptyBorder(25, 15, 20, 15));

        JLabel logo = new JLabel("ENPH");
        logo.setFont(new Font("Arial", Font.BOLD, 32));
        logo.setForeground(Color.WHITE);

        JLabel descripcion = new JLabel(
                "<html>Encuesta Nacional de<br>"
                + "Presupuestos de los Hogares</html>");
        descripcion.setForeground(Color.WHITE);

        lateral.add(logo);
        lateral.add(Box.createVerticalStrut(12));
        lateral.add(descripcion);

        JPanel centro = new JPanel(new GridLayout(0, 1, 12, 12));
        centro.setBackground(new Color(240, 245, 247));
        centro.setBorder(BorderFactory.createEmptyBorder(30, 45, 30, 45));

        JLabel titulo = new JLabel("Menú principal");
        titulo.setFont(new Font("Arial", Font.BOLD, 26));
        titulo.setForeground(oscuro);

        JButton gastos = crearBoton("3. Gestión de gastos diarios");
        JButton ingresos = crearBoton("4. Gestión de ingresos");
        JButton consulta = crearBoton("5. Consulta de información del hogar");
        JButton cerrar = crearBoton("Cerrar sesión");

        centro.add(titulo);
        centro.add(gastos);
        centro.add(ingresos);
        centro.add(consulta);
        centro.add(cerrar);

        principal.add(lateral, BorderLayout.WEST);
        principal.add(centro, BorderLayout.CENTER);
        add(principal);

        gastos.addActionListener(e ->
                new gestiongastos().setVisible(true));

        ingresos.addActionListener(e ->
                new GestionIngresos().setVisible(true));

        consulta.addActionListener(e ->
                new ConsultaENPH().setVisible(true));

        cerrar.addActionListener(e -> {
            new InicioSesion().setVisible(true);
            dispose();
        });
    }

    private JButton crearBoton(String texto) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Arial", Font.BOLD, 14));
        boton.setBackground(verde);
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        return boton;
    }
}
