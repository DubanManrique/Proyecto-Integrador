
package com.mycompany.proyectoin;

import java.awt.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class gestiongastos extends JFrame {

    private JTextField fecha, descripcion, cantidad, valor;
    private JComboBox<String> categoria, unidad, forma;
    private JTable tabla;
    private DefaultTableModel modelo;
    private int siguienteId = 1;

    public gestiongastos() {
        setTitle("ENPH - Gestión de gastos");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        Color oscuro = new Color(6, 72, 63);
        Color verde = new Color(0, 134, 106);

        JPanel principal = new JPanel(new BorderLayout(10, 10));
        principal.setBackground(new Color(240, 245, 247));
        principal.setBorder(BorderFactory.createEmptyBorder(15, 18, 15, 18));

        JLabel titulo = new JLabel("GESTIÓN DE GASTOS DIARIOS");
        titulo.setFont(new Font("Arial", Font.BOLD, 24));
        titulo.setForeground(oscuro);
        principal.add(titulo, BorderLayout.NORTH);

        fecha = new JTextField(LocalDate.now().toString());
        descripcion = new JTextField();
        cantidad = new JTextField();
        valor = new JTextField();

        categoria = new JComboBox<>(new String[]{
            "Alimentación", "Transporte", "Vivienda",
            "Servicios", "Educación", "Salud", "Otros"
        });

        unidad = new JComboBox<>(new String[]{
            "Unidad", "Kg", "Litros", "Libras", "Paquete"
        });

        forma = new JComboBox<>(new String[]{
            "Compra", "Regalo", "Producción propia", "Trueque"
        });

        JPanel formulario = new JPanel(new GridLayout(4, 4, 8, 8));
        formulario.setBorder(BorderFactory.createTitledBorder(
                "Información del gasto"));
        formulario.setBackground(Color.WHITE);

        formulario.add(new JLabel("Fecha (AAAA-MM-DD):"));
        formulario.add(new JLabel("Descripción:"));
        formulario.add(new JLabel("Categoría:"));
        formulario.add(new JLabel("Cantidad:"));
        formulario.add(fecha);
        formulario.add(descripcion);
        formulario.add(categoria);
        formulario.add(cantidad);
        formulario.add(new JLabel("Unidad:"));
        formulario.add(new JLabel("Forma de adquisición:"));
        formulario.add(new JLabel("Valor (COP):"));
        formulario.add(new JLabel(""));
        formulario.add(unidad);
        formulario.add(forma);
        formulario.add(valor);
        formulario.add(new JLabel(""));

        modelo = new DefaultTableModel(new String[]{
            "ID", "Fecha", "Descripción", "Categoría",
            "Cantidad", "Unidad", "Adquisición", "Valor (COP)"
        }, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };

        tabla = new JTable(modelo);
        tabla.setRowHeight(24);
        tabla.getTableHeader().setBackground(new Color(215, 235, 230));

        JPanel centro = new JPanel(new BorderLayout(8, 8));
        centro.setOpaque(false);
        centro.add(formulario, BorderLayout.NORTH);
        centro.add(new JScrollPane(tabla), BorderLayout.CENTER);

        JButton guardar = new JButton("Guardar");
        JButton modificar = new JButton("Modificar");
        JButton eliminar = new JButton("Eliminar");
        JButton limpiar = new JButton("Limpiar");
        JButton volver = new JButton("Volver al menú");

        guardar.setBackground(verde);
        guardar.setForeground(Color.WHITE);

        JPanel botones = new JPanel(new FlowLayout());
        botones.setOpaque(false);
        botones.add(guardar);
        botones.add(modificar);
        botones.add(eliminar);
        botones.add(limpiar);
        botones.add(volver);

        principal.add(centro, BorderLayout.CENTER);
        principal.add(botones, BorderLayout.SOUTH);
        add(principal);

        guardar.addActionListener(e -> guardarGasto());
        modificar.addActionListener(e -> modificarGasto());
        eliminar.addActionListener(e -> eliminarGasto());
        limpiar.addActionListener(e -> limpiar());
        volver.addActionListener(e -> dispose());

        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow() >= 0) {
                cargarSeleccion();
            }
        });
    }

    private BigDecimal leerValor() {
        return new BigDecimal(valor.getText().trim()
                .replace(",", "."));
    }

    private boolean validar() {
        try {
            LocalDate.parse(fecha.getText().trim());

            if (descripcion.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Escribe la descripción del gasto.");
                return false;
            }

            if (Double.parseDouble(cantidad.getText().trim()) <= 0
                    || leerValor().compareTo(BigDecimal.ZERO) <= 0) {
                JOptionPane.showMessageDialog(this,
                        "La cantidad y el valor deben ser mayores que cero.");
                return false;
            }

            return true;
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Revisa la fecha, la cantidad y el valor.");
            return false;
        }
    }

    private void guardarGasto() {
        if (!validar()) return;

        modelo.addRow(new Object[]{
            siguienteId++, fecha.getText().trim(),
            descripcion.getText().trim(), categoria.getSelectedItem(),
            cantidad.getText().trim(), unidad.getSelectedItem(),
            forma.getSelectedItem(), leerValor()
        });

        limpiar();
        JOptionPane.showMessageDialog(this, "Gasto guardado.");
    }

    private void modificarGasto() {
        int fila = tabla.getSelectedRow();

        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Selecciona un gasto.");
            return;
        }
        if (!validar()) return;

        modelo.setValueAt(fecha.getText().trim(), fila, 1);
        modelo.setValueAt(descripcion.getText().trim(), fila, 2);
        modelo.setValueAt(categoria.getSelectedItem(), fila, 3);
        modelo.setValueAt(cantidad.getText().trim(), fila, 4);
        modelo.setValueAt(unidad.getSelectedItem(), fila, 5);
        modelo.setValueAt(forma.getSelectedItem(), fila, 6);
        modelo.setValueAt(leerValor(), fila, 7);

        limpiar();
        JOptionPane.showMessageDialog(this, "Gasto modificado.");
    }

    private void eliminarGasto() {
        int fila = tabla.getSelectedRow();

        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Selecciona un gasto.");
            return;
        }

        if (JOptionPane.showConfirmDialog(this,
                "¿Deseas eliminar este gasto?", "Confirmar",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            modelo.removeRow(fila);
            limpiar();
        }
    }

    private void cargarSeleccion() {
        int f = tabla.getSelectedRow();
        if (f < 0) return;

        fecha.setText(modelo.getValueAt(f, 1).toString());
        descripcion.setText(modelo.getValueAt(f, 2).toString());
        categoria.setSelectedItem(modelo.getValueAt(f, 3));
        cantidad.setText(modelo.getValueAt(f, 4).toString());
        unidad.setSelectedItem(modelo.getValueAt(f, 5));
        forma.setSelectedItem(modelo.getValueAt(f, 6));
        valor.setText(modelo.getValueAt(f, 7).toString());
    }

    private void limpiar() {
        fecha.setText(LocalDate.now().toString());
        descripcion.setText("");
        cantidad.setText("");
        valor.setText("");
        categoria.setSelectedIndex(0);
        unidad.setSelectedIndex(0);
        forma.setSelectedIndex(0);
        tabla.clearSelection();
    }
}
