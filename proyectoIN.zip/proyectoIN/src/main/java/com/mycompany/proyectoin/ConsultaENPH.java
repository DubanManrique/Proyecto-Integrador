
package com.mycompany.proyectoin;

import java.awt.*;
import java.time.LocalDate;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ConsultaENPH extends JFrame {

    private JTextField codigo, direccion, fechaInicio, fechaFin;
    private JComboBox<String> estado;
    private JTable tabla;
    private DefaultTableModel modelo;
    private int siguienteId = 1;

    public ConsultaENPH() {
        setTitle("ENPH - Consulta de información");
        setSize(900, 570);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        Color oscuro = new Color(6, 72, 63);
        Color verde = new Color(0, 134, 106);

        JPanel principal = new JPanel(new BorderLayout(10, 10));
        principal.setBackground(new Color(240, 245, 247));
        principal.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JLabel titulo = new JLabel("CONSULTA DE INFORMACIÓN DEL HOGAR");
        titulo.setFont(new Font("Arial", Font.BOLD, 22));
        titulo.setForeground(oscuro);
        principal.add(titulo, BorderLayout.NORTH);

        codigo = new JTextField();
        direccion = new JTextField();
        fechaInicio = new JTextField();
        fechaFin = new JTextField();
        estado = new JComboBox<>(new String[]{
            "Todos", "En proceso", "Completo", "Con inconsistencias"
        });

        JPanel filtros = new JPanel(new GridLayout(3, 4, 8, 8));
        filtros.setBackground(Color.WHITE);
        filtros.setBorder(BorderFactory.createTitledBorder(
                "Filtros y datos del hogar"));

        filtros.add(new JLabel("Código del hogar:"));
        filtros.add(codigo);
        filtros.add(new JLabel("Dirección:"));
        filtros.add(direccion);
        filtros.add(new JLabel("Fecha inicial (AAAA-MM-DD):"));
        filtros.add(fechaInicio);
        filtros.add(new JLabel("Fecha final (AAAA-MM-DD):"));
        filtros.add(fechaFin);
        filtros.add(new JLabel("Estado:"));
        filtros.add(estado);

        JButton registrar = new JButton("Registrar hogar");
        JButton filtrar = new JButton("Filtrar");
        JButton limpiar = new JButton("Limpiar");
        JButton volver = new JButton("Volver al menú");

        JPanel acciones = new JPanel(new FlowLayout());
        acciones.setOpaque(false);
        acciones.add(registrar);
        acciones.add(filtrar);
        acciones.add(limpiar);
        acciones.add(volver);

        modelo = new DefaultTableModel(new String[]{
            "ID", "Código", "Dirección", "Fecha inicial",
            "Fecha final", "Estado"
        }, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };

        tabla = new JTable(modelo);
        tabla.setRowHeight(24);
        tabla.getTableHeader().setBackground(new Color(215, 235, 230));

        JPanel centro = new JPanel(new BorderLayout(8, 8));
        centro.setOpaque(false);
        centro.add(filtros, BorderLayout.NORTH);
        centro.add(new JScrollPane(tabla), BorderLayout.CENTER);
        centro.add(acciones, BorderLayout.SOUTH);

        principal.add(centro, BorderLayout.CENTER);
        add(principal);

        registrar.addActionListener(e -> registrarHogar());
        filtrar.addActionListener(e -> filtrarHogares());
        limpiar.addActionListener(e -> {
            codigo.setText("");
            direccion.setText("");
            fechaInicio.setText("");
            fechaFin.setText("");
            estado.setSelectedIndex(0);
            mostrarTodos();
        });
        volver.addActionListener(e -> dispose());
    }

    private void registrarHogar() {
        if (codigo.getText().trim().isEmpty()
                || direccion.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Escribe el código y la dirección del hogar.");
            return;
        }

        String inicio = fechaInicio.getText().trim();
        String fin = fechaFin.getText().trim();

        try {
            if (!inicio.isEmpty()) LocalDate.parse(inicio);
            if (!fin.isEmpty()) LocalDate.parse(fin);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Las fechas deben tener formato AAAA-MM-DD.");
            return;
        }

        modelo.addRow(new Object[]{
            siguienteId++, codigo.getText().trim(),
            direccion.getText().trim(), inicio, fin, estado.getSelectedItem()
        });

        JOptionPane.showMessageDialog(this, "Hogar registrado.");
    }

    private void filtrarHogares() {
        String cod = codigo.getText().trim().toLowerCase();
        String dir = direccion.getText().trim().toLowerCase();
        String est = estado.getSelectedItem().toString();

        for (int i = 0; i < modelo.getRowCount(); i++) {
            boolean coincide =
                    modelo.getValueAt(i, 1).toString().toLowerCase().contains(cod)
                    && modelo.getValueAt(i, 2).toString().toLowerCase().contains(dir)
                    && (est.equals("Todos")
                    || modelo.getValueAt(i, 5).toString().equals(est));

            tabla.setRowSelectionInterval(0, 0);
            if (!coincide) {
                // La tabla se filtrará mediante el método mostrarResultados.
            }
        }

        mostrarResultados(cod, dir, est);
    }

    private void mostrarResultados(String cod, String dir, String est) {
        // Se utiliza una tabla temporal para mostrar únicamente coincidencias.
        DefaultTableModel filtrado = new DefaultTableModel(new String[]{
            "ID", "Código", "Dirección", "Fecha inicial",
            "Fecha final", "Estado"
        }, 0);

        for (int i = 0; i < modelo.getRowCount(); i++) {
            boolean coincide =
                    modelo.getValueAt(i, 1).toString().toLowerCase().contains(cod)
                    && modelo.getValueAt(i, 2).toString().toLowerCase().contains(dir)
                    && (est.equals("Todos")
                    || modelo.getValueAt(i, 5).toString().equals(est));

            if (coincide) {
                filtrado.addRow(new Object[]{
                    modelo.getValueAt(i, 0), modelo.getValueAt(i, 1),
                    modelo.getValueAt(i, 2), modelo.getValueAt(i, 3),
                    modelo.getValueAt(i, 4), modelo.getValueAt(i, 5)
                });
            }
        }

        tabla.setModel(filtrado);
    }

    private void mostrarTodos() {
        tabla.setModel(modelo);
    }
}
